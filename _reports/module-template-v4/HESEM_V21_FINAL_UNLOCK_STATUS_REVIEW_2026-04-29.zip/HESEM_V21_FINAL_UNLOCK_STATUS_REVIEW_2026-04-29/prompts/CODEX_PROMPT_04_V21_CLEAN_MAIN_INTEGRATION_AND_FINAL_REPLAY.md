# CODEX PROMPT 04 — V21 Clean Main Integration and Final Replay

You are operating in repository `sanhvo86-hesem/mom`.

## Goal

Safely convert the V21 repair-branch pass into clean current-main evidence.

Final unlock is allowed only if the final report returns exactly:

```text
PHASE2_INTEGRATION_PASS_READY_FOR_PHASE3_PLANNING
```

If any condition is not met, return:

```text
PHASE2_INTEGRATION_PASS_WITH_REPAIRS_PENDING
```

## Hard rules

- Do not start Stage F.
- Do not create or implement a new module/slice.
- Do not modify `mom/portal.html`, `mom/styles/portal.main.css`, `mom/styles/eqms-suite.css`, `mom/styles/density-darkmode.css`, `mom/scripts/portal/01-module-router.js`, `mom/scripts/portal/02-state-auth-ui.js`, or `mom/scripts/portal/40-eqms-shell.js`.
- Do not refresh Chromium snapshots unless the current render is reviewed as correct and explicit approval exists.
- Do not merge unrelated DCC/NLLB changes into V21 unless they are already on `origin/main`.
- Do not claim production, cutover, release, or validated-system readiness.

## Required orientation

Read first:

```text
.ai/AI-WORKFLOW.md
.ai/CONVENTIONS.md
.ai/repo-map.json
AGENTS.md
CLAUDE.md
```

## Critical context from prior audit

The prior V21 final audit passed all technical gates on branch:

```text
codex/v21-backend-gate-repair-20260429
```

But Stage F stayed locked because the audit was not on clean current `main`.

The repair checkout still had modified files:

```text
mom/api/controllers/EqmsAmlController.php
mom/api/controllers/EqmsCsatController.php
mom/api/controllers/EqmsEventsController.php
mom/api/controllers/EqmsFaiController.php
mom/api/controllers/EqmsLessonsLearnedController.php
mom/api/controllers/EqmsSamplingPlansController.php
```

## Phase A — Preserve and isolate the repair diff

1. Record current branch, status, HEAD, and `origin/main`:

```bash
git remote -v
git branch --show-current
git status --short
git rev-parse HEAD
git rev-parse origin/main
git log --oneline --decorate -20
```

2. Save the six-file repair diff to a temp patch:

```bash
mkdir -p /tmp/hesem-v21
REPAIR_PATCH=/tmp/hesem-v21/v21-six-eqms-controller-repair.patch
git diff -- \
  mom/api/controllers/EqmsAmlController.php \
  mom/api/controllers/EqmsCsatController.php \
  mom/api/controllers/EqmsEventsController.php \
  mom/api/controllers/EqmsFaiController.php \
  mom/api/controllers/EqmsLessonsLearnedController.php \
  mom/api/controllers/EqmsSamplingPlansController.php \
  > "$REPAIR_PATCH"
wc -l "$REPAIR_PATCH"
```

3. Stop if the patch is empty. Return `PHASE2_INTEGRATION_PASS_WITH_REPAIRS_PENDING` and explain.

## Phase B — Create clean integration branch from origin/main

Use a separate worktree if the current worktree contains unrelated dirty/untracked files. Preferred:

```bash
git fetch origin
git worktree add ../mom-v21-clean-main-replay origin/main
cd ../mom-v21-clean-main-replay
git switch -c codex/v21-clean-main-replay-20260430
```

If worktree creation is not possible, create a branch from `origin/main` only after preserving the current dirty state safely.

## Phase C — Apply only the six controller repairs

```bash
git apply --check /tmp/hesem-v21/v21-six-eqms-controller-repair.patch
git apply /tmp/hesem-v21/v21-six-eqms-controller-repair.patch
git diff --name-only
```

Expected changed files must be exactly:

```text
mom/api/controllers/EqmsAmlController.php
mom/api/controllers/EqmsCsatController.php
mom/api/controllers/EqmsEventsController.php
mom/api/controllers/EqmsFaiController.php
mom/api/controllers/EqmsLessonsLearnedController.php
mom/api/controllers/EqmsSamplingPlansController.php
```

If anything else changes, stop and return `PHASE2_INTEGRATION_PASS_WITH_REPAIRS_PENDING`.

## Phase D — Run V21 gates on clean integration branch

Run:

```bash
node --check mom/scripts/portal/70-module-template-v4-hydration.js
node --check mom/scripts/portal/71-module-template-v4-routes.js
node --check mom/scripts/portal/72-module-template-v4-bridge.js
node --check mom/scripts/portal/73-module-template-v4-renderers.js
node --check mom/scripts/portal/74-module-template-v4-fixtures.js

grep -n "74-module-template-v4-fixtures" mom/portal.html && echo "FAIL fixture production load" || echo "PASS no fixture production load"

git diff --name-only | grep -E 'mom/styles/(portal.main|eqms-suite|density-darkmode)\.css|mom/scripts/portal/(01-module-router|02-state-auth-ui|40-eqms-shell)\.js|mom/portal\.html' && echo "FAIL forbidden/current portal diff" || echo "PASS forbidden/current portal diff"

python3 - <<'PY'
import json, pathlib, sys
for p in pathlib.Path('tests/fixtures/module-template-v4').rglob('*.json'):
    try:
        json.loads(p.read_text())
        print('PASS json', p)
    except Exception as e:
        print('FAIL json', p, e)
        sys.exit(1)
PY

composer --working-dir=mom run analyse
composer --working-dir=mom run test
composer --working-dir=mom run check
cd mom && vendor/bin/phpunit tests/contract/TransactionalRestTest.php tests/contract/TransactionalLegacyRedirectTest.php && cd ..

cd tests/e2e
npm install --no-package-lock
npx playwright install chromium
PLAYWRIGHT_HTML_OPEN=never ./node_modules/.bin/playwright test --project=chromium --reporter=list
CHROMIUM_EXIT=$?
echo "CHROMIUM_EXIT=${CHROMIUM_EXIT}"
cd ../..
```

## Phase E — Commit repair if all gates pass

Commit only the six source files:

```bash
git status --short
git add \
  mom/api/controllers/EqmsAmlController.php \
  mom/api/controllers/EqmsCsatController.php \
  mom/api/controllers/EqmsEventsController.php \
  mom/api/controllers/EqmsFaiController.php \
  mom/api/controllers/EqmsLessonsLearnedController.php \
  mom/api/controllers/EqmsSamplingPlansController.php

git commit -m "fix(eqms): clear V21 backend gate static analysis findings"
```

Do not commit generated reports unless repository policy explicitly wants them committed.

## Phase F — Produce final report

Create report directory:

```text
_reports/module-template-v4/V21_CLEAN_MAIN_FINAL_REPLAY_2026-04-30/
```

Write these files:

```text
V21_CLEAN_MAIN_FINAL_REPLAY_REPORT.md
V21_CLEAN_MAIN_COMMAND_LOG.md
V21_CLEAN_MAIN_STREAM_STATUS_MATRIX.md
V21_CLEAN_MAIN_DECISION.md
V21_CLEAN_MAIN_SUMMARY.json
```

The report must state:

- branch
- HEAD
- origin/main
- whether the branch was created from origin/main
- exact changed files
- all gate results
- whether current-main evidence exists after integration
- final decision token

## Unlock rule

Return exact unlock token only if all are true:

1. The six-file repair is committed on a branch created from `origin/main`.
2. No unrelated source changes are present.
3. Static guards pass.
4. Portal fixture production-load guard passes.
5. Forbidden/current portal diff guard passes.
6. Fixture JSON parse passes.
7. PHPStan analyse passes.
8. PHPUnit passes.
9. composer check passes.
10. C2 focused contracts pass.
11. Full Chromium Playwright passes with `CHROMIUM_EXIT=0`.
12. Current-main integration replay evidence is written.

If all true:

```text
PHASE2_INTEGRATION_PASS_READY_FOR_PHASE3_PLANNING
```

Otherwise:

```text
PHASE2_INTEGRATION_PASS_WITH_REPAIRS_PENDING
```
