# CODEX PROMPT 01 — V21 Environment Repair And Chromium Replay Only

You are running in the local repository `sanhvo86-hesem/mom`.

## Mission

Repair only the local Playwright Chromium environment blocker reported by `V21_LOCAL_REPLAY_2026-04-29`, then rerun the V21 browser evidence. Do not change application source files in this prompt unless a later explicit approval is given.

## Mandatory posture

- This is development/prototype / pre-production readiness verification only.
- Do not claim production, cutover, release, certification, or validated-system readiness.
- Do not start a new slice.
- Do not instantiate Stage F.
- Do not update snapshots unless an actual rendered visual diff is reproduced and the user explicitly approves snapshot refresh.

## Mandatory orientation

Read these files first and follow them:

```text
.ai/AI-WORKFLOW.md
.ai/CONVENTIONS.md
.ai/repo-map.json
AGENTS.md
CLAUDE.md
```

## Starting evidence

Previous local replay decision:

```text
PHASE2_INTEGRATION_PASS_WITH_REPAIRS_PENDING
```

Previous blocker:

```text
Playwright Chromium full suite BLOCKED because Chromium headless shell was missing from local cache.
```

## Commands to run

From repo root:

```bash
pwd
git remote -v
git branch --show-current
git status --short
git rev-parse HEAD
git rev-parse origin/main || true
git diff --name-only
```

Then run static safety checks again:

```bash
node --check mom/scripts/portal/70-module-template-v4-hydration.js
node --check mom/scripts/portal/71-module-template-v4-routes.js
node --check mom/scripts/portal/72-module-template-v4-bridge.js
node --check mom/scripts/portal/73-module-template-v4-renderers.js
node --check mom/scripts/portal/74-module-template-v4-fixtures.js

grep -n "74-module-template-v4-fixtures" mom/portal.html && echo "FAIL fixture production load" || echo "PASS no fixture production load"

git diff --name-only | grep -E 'mom/styles/(portal.main|eqms-suite|density-darkmode)\.css|mom/scripts/portal/(01-module-router|02-state-auth-ui|40-eqms-shell)\.js|mom/portal\.html' && echo "FAIL forbidden/current portal diff" || echo "PASS forbidden/current portal diff"

python3 - <<'PY'
import json, pathlib, sys
for p in pathlib.Path('tests/fixtures/module-template-v4').rglob('*.json'):
    try:
        json.loads(p.read_text())
        print('PASS json', p)
    except Exception as e:
        print('FAIL json', p, e)
        sys.exit(1)
PY
```

Install the missing browser and rerun Chromium:

```bash
cd tests/e2e
npm install --no-package-lock
npx playwright install chromium
PLAYWRIGHT_HTML_OPEN=never ./node_modules/.bin/playwright test --project=chromium --reporter=list
CHROMIUM_EXIT=$?
echo "CHROMIUM_EXIT=${CHROMIUM_EXIT}"
cd ../..
```

If full Chromium fails after the browser launches, run focused diagnosis only:

```bash
cd tests/e2e
PLAYWRIGHT_HTML_OPEN=never ./node_modules/.bin/playwright test module-template-v4-visual.spec.ts --project=chromium --reporter=list
PLAYWRIGHT_HTML_OPEN=never ./node_modules/.bin/playwright test module-template-v4-live-api.spec.ts --project=chromium --reporter=list
PLAYWRIGHT_HTML_OPEN=never ./node_modules/.bin/playwright test module-template-v4-axe.spec.ts --project=chromium --reporter=list
cd ../..
```

## Output files

Create a new report directory:

```text
_reports/module-template-v4/V21_ENV_REPLAY_2026-04-29/
```

Write:

```text
V21_ENV_REPLAY_REPORT.md
V21_ENV_REPLAY_COMMAND_LOG.md
V21_ENV_REPLAY_SUMMARY.json
```

## Decision tokens

Return exactly one:

```text
V21_CHROMIUM_REPLAY_PASS_BACKEND_REPAIRS_STILL_REQUIRED
V21_CHROMIUM_REPLAY_BLOCKED_ENVIRONMENT_STILL_MISSING
V21_CHROMIUM_REPLAY_FAIL_RENDERED_APP_OR_BASELINE_EVIDENCE
```

Do not return `PHASE2_INTEGRATION_PASS_READY_FOR_PHASE3_PLANNING` in this prompt because backend analyse/test/check are still unresolved from the previous report.
