# CODEX PROMPT 02 — V21 Backend Gate Repair And Replay

You are running in the local repository `sanhvo86-hesem/mom`.

## Mission

Repair the exact backend blockers from the local V21 replay, then rerun backend and V21-critical gates. Keep changes narrow, source-backed, and auditable.

## Mandatory posture

- This is V21 gate repair only, not a new business slice.
- Do not start Stage F.
- Do not create new API routes, new workflow authority, new e-sign behavior, new AI autonomy, or new production/cutover claim.
- Do not weaken PHPStan/PHPUnit config, delete tests, add blanket ignores, or hide failures in reports.
- Do not change frontend current portal forbidden files unless an unrelated blocker proves it and the user explicitly approves.

## Mandatory orientation

Read these files first:

```text
.ai/AI-WORKFLOW.md
.ai/CONVENTIONS.md
.ai/repo-map.json
.ai/symbols.json       # grep only; do not read full file unless necessary
.ai/db-map/index.json  # grep only; do not read full full db map unless necessary
AGENTS.md
CLAUDE.md
```

## Branch/worktree safety

1. Inspect current branch/status/diff.
2. If not already on a remediation branch, create one from current HEAD:

```bash
git checkout -b codex/v21-backend-gate-repair-20260429
```

3. Do not modify unrelated dirty files. Preserve user/prior-agent changes.

## Known backend blockers to repair

### PHPStan — 20 errors

Repair only the listed files/lines unless source inspection proves an adjacent minimal change is needed:

```text
mom/api/controllers/EqmsAmlController.php:227
mom/api/controllers/EqmsCsatController.php:41
mom/api/controllers/EqmsEventsController.php:77
mom/api/controllers/EqmsEventsController.php:182
mom/api/controllers/EqmsEventsController.php:186
mom/api/controllers/EqmsEventsController.php:207
mom/api/controllers/EqmsFaiController.php:137
mom/api/controllers/EqmsLessonsLearnedController.php:113
mom/api/controllers/EqmsLessonsLearnedController.php:257-263
mom/api/controllers/EqmsSamplingPlansController.php:43
mom/api/controllers/EqmsSamplingPlansController.php:138
```

Required repair discipline:

- For redundant `$_GET ??`, replace with source-correct access pattern without changing semantics.
- For unused constants, either remove only if not contractually needed or mark/use in a source-meaningful way. Prefer not to add fake references.
- For `EqmsEventsController::isLoggedIn()`, locate the existing auth/session pattern and use the correct inherited/helper method; do not invent authentication authority.
- For array property access, convert to array-key access only after confirming payload shape.
- For always-true ternary, simplify without changing business behavior.
- For undefined compact variables, initialize or compute the variables correctly before compact; do not remove response fields silently.
- For action methods that should terminate but do not, align declared flow with actual response helper behavior. Do not create hidden mutation or bypass workflow.

### PHPUnit — one failure

Investigate:

```text
MOM\Tests\Unit\Services\DocumentHeaderServiceFallbackTest::testRenderFallsBackToLegacyCatalogTitleAndDocDescriptionSubtitle
Expected: QMS Manual
Actual:   QMS-MAN-001
```

Repair rule:

- Determine the source-of-truth contract for DCC fallback title.
- If the service should return legacy catalog title, fix service behavior.
- If the new correct behavior is doc code, update the test only with a written rationale and source contract evidence.
- Do not weaken the DCC header standard.

## Required validation commands

Run these before final decision:

```bash
composer --working-dir=mom run analyse
composer --working-dir=mom run test
composer --working-dir=mom run check
cd mom && vendor/bin/phpunit tests/contract/TransactionalRestTest.php tests/contract/TransactionalLegacyRedirectTest.php && cd ..
```

Also rerun V21 static frontend guards to ensure no collateral drift:

```bash
node --check mom/scripts/portal/70-module-template-v4-hydration.js
node --check mom/scripts/portal/71-module-template-v4-routes.js
node --check mom/scripts/portal/72-module-template-v4-bridge.js
node --check mom/scripts/portal/73-module-template-v4-renderers.js
node --check mom/scripts/portal/74-module-template-v4-fixtures.js

grep -n "74-module-template-v4-fixtures" mom/portal.html && echo "FAIL fixture production load" || echo "PASS no fixture production load"
```

If Playwright Chromium was already installed by Prompt 01, rerun full Chromium too:

```bash
cd tests/e2e
PLAYWRIGHT_HTML_OPEN=never ./node_modules/.bin/playwright test --project=chromium --reporter=list
CHROMIUM_EXIT=$?
echo "CHROMIUM_EXIT=${CHROMIUM_EXIT}"
cd ../..
```

## Output files

Create:

```text
_reports/module-template-v4/V21_BACKEND_GATE_REPAIR_2026-04-29/
```

Write:

```text
V21_BACKEND_GATE_REPAIR_REPORT.md
V21_BACKEND_GATE_REPAIR_COMMAND_LOG.md
V21_BACKEND_GATE_REPAIR_DIFF_SUMMARY.md
V21_BACKEND_GATE_REPAIR_SUMMARY.json
```

## Final decision tokens

Return exactly one:

```text
V21_BACKEND_GATE_REPAIR_PASS_READY_FOR_FINAL_UNLOCK_AUDIT
V21_BACKEND_GATE_REPAIR_PASS_CHROMIUM_STILL_REQUIRED
V21_BACKEND_GATE_REPAIR_BLOCKED_REQUIRES_OWNER_DECISION
V21_BACKEND_GATE_REPAIR_FAIL_BLOCK_NEXT
```

Do not return Stage F unlock in this prompt. Final unlock belongs to `CODEX_PROMPT_03_V21_FINAL_UNLOCK_AUDIT.md`.
