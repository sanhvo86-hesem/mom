# CODEX PROMPT 03 — V21 Final Unlock Audit

You are running in the local repository `sanhvo86-hesem/mom`.

## Mission

Perform a final V21 audit after environment replay and backend repair. Return `PHASE2_INTEGRATION_PASS_READY_FOR_PHASE3_PLANNING` only if all required current-main evidence is present and current gates pass.

## Non-negotiable posture

- This is a gate audit, not implementation.
- Do not start Stage F inside this prompt.
- Do not create new slices, routes, workflow authority, e-sign behavior, AI autonomy, or production/cutover claims.
- If evidence is missing, return a blocker token. Do not infer pass.

## Required orientation

Read:

```text
.ai/AI-WORKFLOW.md
.ai/CONVENTIONS.md
.ai/repo-map.json
AGENTS.md
CLAUDE.md
```

## Required current-state checks

Run:

```bash
pwd
git remote -v
git branch --show-current
git status --short
git rev-parse HEAD
git rev-parse origin/main || true
git diff --name-only
git log --oneline --decorate -20
```

## Required validation replay

Run all of these, even if previous reports say pass:

```bash
node --check mom/scripts/portal/70-module-template-v4-hydration.js
node --check mom/scripts/portal/71-module-template-v4-routes.js
node --check mom/scripts/portal/72-module-template-v4-bridge.js
node --check mom/scripts/portal/73-module-template-v4-renderers.js
node --check mom/scripts/portal/74-module-template-v4-fixtures.js

grep -n "74-module-template-v4-fixtures" mom/portal.html && echo "FAIL fixture production load" || echo "PASS no fixture production load"

git diff --name-only | grep -E 'mom/styles/(portal.main|eqms-suite|density-darkmode)\.css|mom/scripts/portal/(01-module-router|02-state-auth-ui|40-eqms-shell)\.js|mom/portal\.html' && echo "FAIL forbidden/current portal diff" || echo "PASS forbidden/current portal diff"

python3 - <<'PY'
import json, pathlib, sys
for p in pathlib.Path('tests/fixtures/module-template-v4').rglob('*.json'):
    try:
        json.loads(p.read_text())
        print('PASS json', p)
    except Exception as e:
        print('FAIL json', p, e)
        sys.exit(1)
PY

composer --working-dir=mom run analyse
composer --working-dir=mom run test
composer --working-dir=mom run check
cd mom && vendor/bin/phpunit tests/contract/TransactionalRestTest.php tests/contract/TransactionalLegacyRedirectTest.php && cd ..

cd tests/e2e
npm install --no-package-lock
npx playwright install chromium
PLAYWRIGHT_HTML_OPEN=never ./node_modules/.bin/playwright test --project=chromium --reporter=list
CHROMIUM_EXIT=$?
echo "CHROMIUM_EXIT=${CHROMIUM_EXIT}"
cd ../..
```

## Review required historical/current streams

Verify and classify:

```text
CAPA Slice 4
NQCASE live API toggle
Transactional REST C2
Cross-browser/Chromium
Current portal safety
Backend analyse/test/check
```

## Output files

Create:

```text
_reports/module-template-v4/V21_FINAL_UNLOCK_AUDIT_2026-04-29/
```

Write:

```text
V21_FINAL_UNLOCK_AUDIT_REPORT.md
V21_FINAL_STREAM_STATUS_MATRIX.md
V21_FINAL_COMMAND_LOG.md
V21_FINAL_DECISION.md
V21_FINAL_SUMMARY.json
```

## Decision rule

Return exactly one token.

Return this token only if every required gate above passes on current local evidence:

```text
PHASE2_INTEGRATION_PASS_READY_FOR_PHASE3_PLANNING
```

Otherwise return one of:

```text
PHASE2_INTEGRATION_PASS_WITH_REPAIRS_PENDING
PHASE2_INTEGRATION_BLOCKED_CROSS_BROWSER
PHASE2_INTEGRATION_FAIL_BLOCK_NEXT
```

If the final token is not `PHASE2_INTEGRATION_PASS_READY_FOR_PHASE3_PLANNING`, Stage F remains locked.
